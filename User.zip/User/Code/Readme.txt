Prerequisites:

Microsoft Visual Studio 2010

Microsoft SQL Server Management Studio
must be installed.

According to the schema specified,a database needs to be created.

Run the code in visual studio to get the desired output.

By,

Team: Pretty_Coders

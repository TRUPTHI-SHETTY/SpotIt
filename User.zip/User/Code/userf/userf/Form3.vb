﻿Imports System.Data.SqlClient
Public Class Form3
    Dim connection As New SqlConnection("Server=dell;Database=SuperMarket;Integrated Security=true")
    Private Sub Form3_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'NAVIGATE2DataSet.LECTURERS' table. You can move, or remove it, as needed.

    End Sub
    Private Sub FilterData(valueToSearch As String)
        ' SELECT * FROM staff where concat (ID,NAME,DEPARTMENT,LOCATION) LIKE "%F%" '

        Dim searchQuery As String = "SELECT * FROM Market where CONCAT(Shop,Category,Item,Location,Availability,Offers) like '%" & valueToSearch & "%' "
        Dim command As New SqlCommand(searchQuery, connection)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable()

        adapter.Fill(table)

        DataGridView1.DataSource = table

    End Sub

    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged
        FilterData(TextBox1.Text)
    End Sub


    Private Sub DataGridView2_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub
End Class
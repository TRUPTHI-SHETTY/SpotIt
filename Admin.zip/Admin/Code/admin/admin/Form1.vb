﻿
Imports System.Data.SqlClient
Public Class Form1
    Dim connection As New SqlConnection("Server=dell;Database=SuperMarket;Integrated Security=true")
        

    Private Sub BTN_INSERT_Click(sender As System.Object, e As System.EventArgs) Handles BTN_INSERT.Click
        Try
            If TextBox5.Text = "" Then
                MsgBox("Shop Name is required!")
            ElseIf ComboBox1.Text = "" Then
                MsgBox("Category is required!")
            ElseIf TextBox2.Text = "" Then
                MsgBox("Item name Required!")
            ElseIf TextBox1.Text = "" Then
                MsgBox("Location is Required!")
            ElseIf TextBox3.Text = "" Then
                MsgBox("Status of Availability is required")
            ElseIf TextBox4.Text = "" Then
                MsgBox("Offers is Required!")
            Else
                Dim command As New SqlCommand("insert into Market(Shop,Category,Item,Location,Availability,Offers) values ('" & TextBox5.Text & "','" & ComboBox1.Text & "','" & TextBox2.Text & "','" & TextBox1.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "')", connection)
                connection.Open()
                If command.ExecuteNonQuery() = 1 Then
                    MessageBox.Show("Item added")
                Else
                    MessageBox.Show("Item not added")

                End If
                connection.Close()
            End If
        Catch ex As SqlException
            If ex.Number = 2627 Then
                MessageBox.Show("Item is already present in database,Try Updating!!")
            End If

        End Try
        
   

    End Sub
    Private Sub BTN_UPDATE_Click(sender As System.Object, e As System.EventArgs) Handles BTN_UPDATE.Click
        If TextBox5.Text = "" Then
            MsgBox("Shop Name is required!")
        ElseIf ComboBox1.Text = "" Then
                MsgBox("Category is required!")
        ElseIf TextBox2.Text = "" Then
            MsgBox("Item name Required!")
        ElseIf TextBox1.Text = "" Then
            MsgBox("Location is Required!")
        ElseIf TextBox3.Text = "" Then
            MsgBox("Status of Availability is required")
        ElseIf TextBox4.Text = "" Then
            MsgBox("Offers is Required!")
        Else

            Dim sqlcommand As String = "Update Market Set Shop='" & TextBox5.Text & "',Category='" & ComboBox1.Text & "',Location='" & TextBox1.Text & "',Availability='" & TextBox3.Text & "',Offers='" & TextBox4.Text & "' WHERE Item='" & TextBox2.Text & "'"
            Dim command As New SqlCommand(sqlcommand, connection)
            connection.Open()

            If command.ExecuteNonQuery() = 1 Then
                MessageBox.Show("Item updated")
            Else
                MessageBox.Show("Item not updated")

            End If

            connection.Close()
            End If
    End Sub

    Private Sub BTN_DELETE_Click(sender As Object, e As EventArgs) Handles BTN_DELETE.Click

            If TextBox2.Text = "" Then
                MsgBox("Item name is required!")

            Else
                Dim deleteQuery As String = "DELETE from Market WHERE Item='" & TextBox2.Text & "'"
                Dim command As New SqlCommand(deleteQuery, connection)
                connection.Open()

                If command.ExecuteNonQuery() = 1 Then
                    MessageBox.Show("Item deleted")
                Else
                    MessageBox.Show("Item not deleted")

                End If
                connection.Close()
            End If
    End Sub


    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("Fruits")
        ComboBox1.Items.Add("Drinks")
        ComboBox1.Items.Add("Grocery")
        ComboBox1.Items.Add("Cosmetics")
        ComboBox1.Items.Add("Vegetables")
        ComboBox1.Items.Add("Clothes")
        ComboBox1.Items.Add("Sweets and Snacks")
        ComboBox1.Items.Add("Cleaning Supplies")

    End Sub

    Private Sub Label1_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Label2_Click(sender As System.Object, e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Label4_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Label5_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub PictureBox1_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Label1_Click_1(sender As System.Object, e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label3_Click_1(sender As System.Object, e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label7_Click(sender As System.Object, e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub Label8_Click(sender As System.Object, e As System.EventArgs) Handles Label8.Click

    End Sub
End Class
